---
name: Fluid Infrastructure System
colors:
  surface: '#f7fafc'
  surface-dim: '#d8dadd'
  surface-bright: '#f7fafc'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f1f4f6'
  surface-container: '#eceef1'
  surface-container-high: '#e6e8eb'
  surface-container-highest: '#e0e3e5'
  on-surface: '#181c1e'
  on-surface-variant: '#3f484d'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#6f787e'
  outline-variant: '#bfc8cd'
  surface-tint: '#006684'
  primary: '#00556d'
  on-primary: '#ffffff'
  primary-container: '#0f6e8c'
  on-primary-container: '#c1eaff'
  inverse-primary: '#85d0f2'
  secondary: '#545f73'
  on-secondary: '#ffffff'
  secondary-container: '#d5e0f8'
  on-secondary-container: '#586377'
  tertiary: '#724200'
  on-tertiary: '#ffffff'
  tertiary-container: '#8f5919'
  on-tertiary-container: '#ffdec0'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#bde9ff'
  primary-fixed-dim: '#85d0f2'
  on-primary-fixed: '#001f2a'
  on-primary-fixed-variant: '#004d64'
  secondary-fixed: '#d8e3fb'
  secondary-fixed-dim: '#bcc7de'
  on-secondary-fixed: '#111c2d'
  on-secondary-fixed-variant: '#3c475a'
  tertiary-fixed: '#ffdcbd'
  tertiary-fixed-dim: '#ffb870'
  on-tertiary-fixed: '#2c1600'
  on-tertiary-fixed-variant: '#693c00'
  background: '#f7fafc'
  on-background: '#181c1e'
  surface-variant: '#e0e3e5'
typography:
  display-lg:
    fontFamily: plusJakartaSans
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: plusJakartaSans
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: plusJakartaSans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  title-md:
    fontFamily: plusJakartaSans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: plusJakartaSans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: plusJakartaSans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-numeric:
    fontFamily: spaceGrotesk
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
  clock-display:
    fontFamily: spaceGrotesk
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 24px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 40px
  container-margin: 24px
  gutter: 16px
---

## Brand & Style
The design system is engineered for utility, reliability, and modern technical oversight in water distribution management. The brand personality is professional and precise, balancing the heavy industrial nature of infrastructure with a high-tech, data-driven interface. 

The aesthetic follows a **Modern/Corporate** direction with selective **Glassmorphism** for authentication and high-level dashboard overlays. This approach ensures that while the core data remains legible and grounded, the interface feels forward-thinking and innovative. The visual language emphasizes transparency—mirroring the clarity of the resource being managed.

## Colors
The palette is anchored by a deep Teal primary color, symbolizing water and professional stability. 

- **Primary (#0F6E8C):** Used for primary actions, active states, and branding elements.
- **Surface/Background (#F3F6F8):** A cool, neutral grey-blue that reduces eye strain during long monitoring sessions.
- **Typography:** Slate-800 provides high-contrast legibility for data, while Slate-500 is reserved for metadata and secondary descriptions.
- **Glassmorphism:** For authentication cards, use `rgba(255, 255, 255, 0.1)` with a `backdrop-filter: blur(24px)` to create depth against dynamic backgrounds.

## Typography
This design system utilizes **Plus Jakarta Sans** for all primary interface text, providing a contemporary, geometric, and highly readable experience. For technical readouts, timestamps, and the system clock, **Space Grotesk** is used to provide a "computational" and futuristic feel that distinguishes live data from static labels.

Hierarchies are strictly enforced to ensure that high-volume data tables and charts remain scannable. Use `label-numeric` for all system-generated values and sensor readings to maintain a technical edge.

## Layout & Spacing
The layout employs a **Fluid Grid** model with a 12-column structure for desktop. 

- **Desktop (1440px+):** 12 columns, 24px margins, 16px gutters.
- **Tablet (768px - 1439px):** 8 columns, 16px margins, 16px gutters.
- **Mobile (<767px):** 4 columns, 16px margins, 12px gutters.

The spacing rhythm is based on a 4px baseline grid. Components should use `md` (16px) for standard internal padding and `lg` (24px) to separate distinct functional sections.

## Elevation & Depth
Depth is communicated through **Tonal Layers** and precise **Low-Contrast Outlines**. 

Shadows are used sparingly; when applied, they should be extremely diffused (e.g., `box-shadow: 0 10px 30px rgba(15, 110, 140, 0.05)`) to maintain a clean, professional aesthetic. 

The primary depth mechanism is the use of surface tiers:
1. **Level 0 (Background):** #F3F6F8.
2. **Level 1 (Cards/Content):** #FFFFFF with a 1px border (#E2E8F0).
3. **Level 2 (Modals/Dropdowns):** #FFFFFF with a soft ambient shadow.
4. **Special (Auth):** Glassmorphic surfaces with a 1px semi-transparent white border to simulate high-end frosted glass.

## Shapes
A **Rounded** shape language is used to soften the technical nature of the application. 

Standard components (buttons, inputs, cards) utilize a 0.5rem (8px) radius. Larger layout containers or dashboard widgets may scale up to 1rem (16px) to create clear visual groupings. Interactive elements like "Chips" or "Status Tags" use a full pill-shape (999px) to distinguish them from actionable buttons.

## Components

### Buttons
Primary buttons feature an **animated slide-over effect**. On hover, a secondary color or a darker shade of teal slides in from the left to right behind the label. Transitions should be `300ms cubic-bezier(0.4, 0, 0.2, 1)`.

### Input Fields
For the general dashboard, use outlined fields. For **Authentication**, use the **Floating Label** style with a simple underline. The underline should thicken and change to the primary teal color upon focus.

### Cards
Cards are white with a subtle 1px Slate-200 border. Dashboard cards containing sensor data should have a top-border accent (2px) in primary teal to indicate activity.

### Chips & Status Indicators
Status indicators (e.g., "Active," "Leaking," "Offline") should use a subtle background tint of the status color (Green, Red, Amber) with a dark text version of the same hue, following the pill-shaped geometry.

### Custom Component: The Distribution Clock
A specialized component for the system header, displaying the current synchronized system time using Space Grotesk. It should be presented in a monospaced-style layout to prevent layout shift during second intervals.