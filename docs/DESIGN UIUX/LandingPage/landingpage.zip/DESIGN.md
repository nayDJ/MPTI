---
name: Fluid Infrastructure
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#3f484d'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#6f787e'
  outline-variant: '#bfc8cd'
  surface-tint: '#006684'
  primary: '#00556d'
  on-primary: '#ffffff'
  primary-container: '#0f6e8c'
  on-primary-container: '#c1eaff'
  inverse-primary: '#85d0f2'
  secondary: '#5c5e63'
  on-secondary: '#ffffff'
  secondary-container: '#e1e2e8'
  on-secondary-container: '#626469'
  tertiary: '#3f4f64'
  on-tertiary: '#ffffff'
  tertiary-container: '#57677d'
  on-tertiary-container: '#d6e6ff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#bde9ff'
  primary-fixed-dim: '#85d0f2'
  on-primary-fixed: '#001f2a'
  on-primary-fixed-variant: '#004d64'
  secondary-fixed: '#e1e2e8'
  secondary-fixed-dim: '#c5c6cc'
  on-secondary-fixed: '#191c20'
  on-secondary-fixed-variant: '#44474b'
  tertiary-fixed: '#d3e4fe'
  tertiary-fixed-dim: '#b7c8e1'
  on-tertiary-fixed: '#0b1c30'
  on-tertiary-fixed-variant: '#38485d'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: '0'
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '300'
    lineHeight: 26px
    letterSpacing: '0'
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '300'
    lineHeight: 22px
    letterSpacing: '0'
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 48px
  section-gap: 80px
---

## Brand & Style

This design system embodies a "High-Tech Minimalist" aesthetic, optimized for high-end SaaS environments where clarity and efficiency are paramount. The brand personality is professional, sophisticated, and intentionally understated, allowing user data and workflows to take center stage. 

The visual narrative is built on the principle of "Reductionist Precision." It leverages expansive whitespace, a disciplined color palette, and subtle depth to create a focused, "cool" atmosphere. By removing traditional containers and heavy borders, the interface feels light and unencumbered, evoking a sense of modern, forward-thinking infrastructure.

## Colors

The palette is anchored by the signature Teal, used sparingly for primary actions and critical status indicators to maintain its impact. The supporting cast is a sophisticated range of charcoals and cool grays.

- **Primary (#0F6E8C):** Used for key call-to-actions and active states.
- **Deep Charcoal (#1A1D21):** Applied to primary headings and high-contrast text to ensure a premium feel.
- **Slate Gray (#64748B):** Reserved for secondary text and icons, providing a clear hierarchy without visual noise.
- **Surface Gray (#F8FAFC):** The primary background color for page sections and subtle container fills.
- **Pure White (#FFFFFF):** Used for elevated cards and components to create separation via tonal layering rather than borders.

## Typography

This design system utilizes Plus Jakarta Sans exclusively to maintain a cohesive, modern identity. The hierarchy is established through extreme contrast in weights: headings are bold and authoritative with tight letter-spacing, while body text is light (300 weight) to create an airy, premium feel.

Headlines should always use the Deep Charcoal color. Body text should use a slightly softer gray to reduce eye strain over long reading sessions. Labels utilize a semi-bold weight and subtle letter-spacing for maximum legibility at small sizes.

## Layout & Spacing

The layout philosophy follows a strict fluid grid with generous margins to enforce the minimalist aesthetic. A 12-column grid is used for desktop, scaling down to 4 columns for mobile. 

Whitespace is treated as a first-class design element. Section vertical spacing is intentionally large (80px+) to allow the user's focus to rest on one functional block at a time. Internal component spacing follows a 4px baseline grid, ensuring mathematical harmony across all UI elements.

## Elevation & Depth

To achieve a "borderless" look, the design system relies on tonal layering and ambient shadows. Depth is used to signify interactivity and hierarchy rather than physical separation.

- **Level 0 (Base):** Surface Gray (#F8FAFC) background.
- **Level 1 (Cards/Containers):** Pure White (#FFFFFF) surfaces with a very subtle, diffused shadow (0px 4px 20px rgba(0,0,0,0.04)). No borders.
- **Level 2 (Hover/Active):** Slightly increased shadow spread (0px 8px 30px rgba(0,0,0,0.08)) to indicate tangibility.

The result is a UI that feels "stacked" rather than "boxed," maintaining a clean and efficient flow.

## Shapes

The shape language is consistently rounded to soften the technical nature of the product. A standard radius of 12px is used for most components, while larger cards and containers utilize 16px or 24px to emphasize their structural role. This consistent curvature creates a approachable yet precise "tech-forward" feel.

## Components

- **Buttons:** Primary buttons are solid Teal with white text and no border. Secondary buttons are "ghost" style with a light gray background fill (#F1F5F9) and Charcoal text.
- **Inputs:** Fields are borderless, using a light gray background fill that transitions to a white background with a subtle Teal focus ring (shadow-based) when active.
- **Cards:** Defined by white fills and ambient shadows rather than outlines. Padding should be generous (minimum 32px).
- **Chips:** Small, low-contrast pills using the light body font weight. Backgrounds should be a 5% opacity of the text color.
- **Lists:** Rows are separated by whitespace and subtle background shifts on hover rather than horizontal rules.
- **Checkboxes/Radio:** Minimalist circles/squares with a solid Teal fill for the active state. The "off" state is a subtle gray fill, avoiding high-contrast outlines.